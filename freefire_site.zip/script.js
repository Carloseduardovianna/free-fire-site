function baixar() {
  // Coloque o link de download real abaixo
  window.location.href = "https://example.com/seu-arquivo.zip";
}